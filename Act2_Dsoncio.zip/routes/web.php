<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

Route::view('/', 'welcome', [
    'greeting' => 'Hello, World!',
    'name' => 'John Doe',
    'age' => 30,
    'tasks' => [
        'Learn Laravel',
        'Build a project',
        'Deploy to production',
    ],
]);

Route::view('/about', 'about');
Route::view('/contact', 'contact');


Route::get('/formtest', function () {
    $emails = session()->get('emails', []);
    return view('formtest', [
        'emails' => $emails,
    ]);
});


Route::post('/formtest', function (Request $request) {
    
    $request->validate([
        'email' => 'required|email'
    ]);

    $email = $request->input('email');
    $emails = session()->get('emails', []);

   
    if (in_array($email, $emails)) {
        return redirect('/formtest')->with('error', 'Email already exists in the list!');
    }

    
    if (count($emails) >= 5) {
        return redirect('/formtest')->with('error', 'Limit reached! Only 5 emails allowed.');
    }

 
    session()->push('emails', $email);

    return redirect('/formtest')->with('success', 'Email added successfully!');
});


Route::post('/delete-email/{index}', function ($index) {
    $emails = session()->get('emails', []);

    if (isset($emails[$index])) {
        unset($emails[$index]);
        
        session()->put('emails', array_values($emails));
    }

    return redirect('/formtest')->with('success', 'Email deleted!');
});

Route::get('/delete-emails', function () {
    session()->forget('emails');
    return redirect('/formtest');
});