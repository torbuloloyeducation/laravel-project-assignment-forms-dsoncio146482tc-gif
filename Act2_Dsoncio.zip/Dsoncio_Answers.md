Activity 2 Reflection - SONCIO

Task 1: Flow Explanation
Inig input sa user og email sa form, ipadala kini padung sa server ipaagi sa usa ka POST request. Ang Laravel mo-validate sa maong data then, ug kung pasado, i-store kini sa usa ka 'array' sulod sa Session storage. Human, ang page mo reload ug i-retrieve ang mga emails gikan sa session aron ipakita kini balik sa user pinaagi sa usa ka listahan.

Reflection Questions
1. What is the difference between GET and POST?
   - Ang GET gigamit para mokuha og data (makita ang parameters sa URL), samtang ang POST gigamit para magpadala o mag-save og sensitive data padung sa server (tago ang data).

2. Why do we use @csrf in forms?
   - Gigamit kini isip security measure aron mapugngan ang Cross-Site Request Forgery (CSRF). Siguroon niini nga ang request gikan gyud sa authorized user sa website.

3. What is session used for in this activity?
   - Gigamit ang session as a temporary storage sa mga emails samtang wala pa kitay database nga gigamit.

4. What happens if session is cleared?
   - Kung ma,clear ang session ( inig close sa browser o manual clearing), mawala ang tanang na-save nga emails ug mobalik sa blangko ang listahan.

salamat sirrr =)