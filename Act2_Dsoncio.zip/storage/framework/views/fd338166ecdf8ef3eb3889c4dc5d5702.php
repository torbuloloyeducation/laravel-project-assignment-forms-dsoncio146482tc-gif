<div class="card" style="border: 10px solid #c71b1b; padding: 20px; border-radius: 5px;">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\Administrator\Downloads\laravel-project-assignment-forms-dsoncio146482tc-gif-main\resources\views/components/card.blade.php ENDPATH**/ ?>